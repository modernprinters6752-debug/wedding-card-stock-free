import { createFileRoute } from '@tanstack/react-router'
import { bad, currentUser, db, getSetting, MIN_QTY, ok, whatsappLink } from '../../lib/app.server'

export const Route = createFileRoute('/api/order-update')({
  server: { handlers: { POST: async ({ request }) => {
    const u = await currentUser(request)
    if (!u || u.role !== 'customer') return bad('Customer access required', 403)
    const b = await request.json() as any
    const id = Number(b.order_id)
    if (b.action === 'delete') {
      if (!id) return bad('Invalid order')
      const d = db()
      const o = await d.prepare('SELECT id,customer_id,status FROM orders WHERE id=?').bind(id).first<any>()
      if (!o || o.customer_id !== u.id || o.status !== 'placed') return bad('Order cannot be deleted', 403)
      const items = await d.prepare('SELECT card_id,quantity FROM order_items WHERE order_id=?').bind(id).all<any>()
      try {
        await d.batch(items.results.map((i:any) => d.prepare('UPDATE cards SET stock=stock+? WHERE id=?').bind(Number(i.quantity), Number(i.card_id))))
        await d.prepare('DELETE FROM order_items WHERE order_id=?').bind(id).run()
        await d.prepare('DELETE FROM orders WHERE id=?').bind(id).run()
        const adminWhatsapp = await getSetting('admin_whatsapp_number')
        const message = `🔴 ORDER CANCELLED / DELETED\nOrder #${id}\nCustomer: ${u.name}\nWhatsApp: +${u.username}\n\nThe customer cancelled this order. Stock has been returned automatically.`
        return ok({ok:true,whatsapp_url:adminWhatsapp?whatsappLink(adminWhatsapp,message):''})
      } catch { return bad('Could not delete order',500) }
    }
    const items = Array.isArray(b.items) ? b.items : []
    if (!id || !items.length) return bad('Invalid order')
    for (const i of items) {
      if (!Number.isInteger(Number(i.card_id)) || !Number.isInteger(Number(i.quantity)) || Number(i.quantity) < MIN_QTY) return bad(`Minimum quantity is ${MIN_QTY} PCS per card`)
    }
    const d = db()
    const o = await d.prepare('SELECT id,customer_id,status FROM orders WHERE id=?').bind(id).first<any>()
    if (!o || o.customer_id !== u.id || o.status !== 'placed') return bad('Order cannot be edited', 403)
    const old = await d.prepare('SELECT card_id,quantity FROM order_items WHERE order_id=?').bind(id).all<any>()
    const om = new Map<number,number>(old.results.map((x:any) => [Number(x.card_id), Number(x.quantity)] as [number,number]))
    const nm = new Map<number,number>(items.map((x:any) => [Number(x.card_id), Number(x.quantity)] as [number,number]))
    const delta = new Map<number,number>()
    for (const [k,v] of om) delta.set(k, (delta.get(k) || 0) + v)
    for (const [k,v] of nm) delta.set(k, (delta.get(k) || 0) - v)
    const rs = await d.batch([...delta].filter(([,v]) => v !== 0).map(([k,v]) => v > 0 ? d.prepare('UPDATE cards SET stock=stock+? WHERE id=?').bind(v,k) : d.prepare('UPDATE cards SET stock=stock-? WHERE id=? AND stock>=?').bind(-v,k,-v)))
    if (rs.some(x => Number(x.meta.changes) !== 1)) return bad('Not enough stock for the edited order', 409)
    try {
      await d.prepare('DELETE FROM order_items WHERE order_id=?').bind(id).run()
      await d.batch(items.map((i:any) => d.prepare('INSERT INTO order_items(order_id,card_id,quantity) VALUES(?,?,?)').bind(id, Number(i.card_id), Number(i.quantity))))
      await d.prepare('UPDATE orders SET updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(id).run()
      const lines:string[] = []
      for (const i of items) {
        const c = await d.prepare('SELECT card_no,title FROM cards WHERE id=?').bind(Number(i.card_id)).first<any>()
        lines.push(`${c?.card_no || i.card_id} · ${c?.title || 'Card'} × ${Number(i.quantity)} PCS`)
      }
      const adminWhatsapp = await getSetting('admin_whatsapp_number')
      const message = `🟡 ORDER UPDATED\nOrder #${id}\nCustomer: ${u.name}\nWhatsApp: +${u.username}\n\n${lines.join('\n')}\n\nTotal PCS: ${items.reduce((s:any,i:any) => s + Number(i.quantity), 0)}\nPlease review the updated order.`
      return ok({ ok: true, whatsapp_url: adminWhatsapp ? whatsappLink(adminWhatsapp, message) : '' })
    } catch { return bad('Could not update order', 500) }
  } } }
})
