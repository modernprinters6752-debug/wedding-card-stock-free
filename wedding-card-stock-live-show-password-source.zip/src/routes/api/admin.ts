import { createFileRoute } from '@tanstack/react-router'
import { bad, createUser, currentUser, db, normalizeWhatsapp, ok, setSetting } from '../../lib/app.server'

export const Route = createFileRoute('/api/admin')({
  server: { handlers: { POST: async ({ request }) => {
    const u = await currentUser(request)
    if (!u || u.role !== 'admin') return bad('Admin access required', 403)
    const b = await request.json() as any


    if (b.action === 'set_admin_whatsapp') {
      try {
        const whatsapp = normalizeWhatsapp(b.whatsapp)
        await setSetting('admin_whatsapp_number', whatsapp)
        return ok({ ok: true, whatsapp })
      } catch (e) { return bad(e instanceof Error ? e.message : 'Enter a valid WhatsApp number') }
    }

    if (b.action === 'update_stock') {
      if (!Number.isInteger(Number(b.card_id)) || !Number.isInteger(Number(b.stock)) || Number(b.stock) < 0) return bad('Enter a valid stock quantity')
      const r = await db().prepare('UPDATE cards SET stock=? WHERE id=? AND active=1').bind(Number(b.stock), Number(b.card_id)).run()
      return Number(r.meta.changes) === 1 ? ok({ ok: true }) : bad('Card not found', 404)
    }

    if (b.action === 'card') {
      if (!b.card_no || !b.title || !Number.isInteger(Number(b.stock)) || Number(b.stock) < 0) return bad('Enter valid card details')
      try {
        await db().prepare('INSERT INTO cards(card_no,title,stock) VALUES(?,?,?)').bind(String(b.card_no).trim(), String(b.title).trim(), Number(b.stock)).run()
        return ok({ ok: true })
      } catch { return bad('Card number already exists or is invalid') }
    }

    return bad('Unknown action')
  } } }
})
