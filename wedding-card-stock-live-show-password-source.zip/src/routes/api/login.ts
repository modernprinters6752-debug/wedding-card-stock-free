import {createFileRoute} from '@tanstack/react-router'
import {bad,cookie,createUser,login,normalizeWhatsapp,ok} from '../../lib/app.server'

export const Route=createFileRoute('/api/login')({server:{handlers:{POST:async({request})=>{
  const b=await request.json() as any
  if(b.action==='signup'){
    if(typeof b.whatsapp!=='string'||typeof b.password!=='string'||typeof b.name!=='string')return bad('Name, WhatsApp number and password are required')
    if(b.password.length<6)return bad('Password must be at least 6 characters')
    try{
      const whatsapp=normalizeWhatsapp(b.whatsapp)
      await createUser(whatsapp,b.password,'customer',b.name)
      const r=await login(whatsapp,b.password)
      if(!r)return bad('Account created, but automatic login failed',500)
      return ok({ok:true,user:r.user},{headers:{'Set-Cookie':cookie(r.token)}})
    }catch(e){
      const message=e instanceof Error?e.message:'Could not create customer account'
      if(message.includes('UNIQUE')||message.includes('unique')||message.includes('constraint'))return bad('This WhatsApp number is already registered. Please login with your password.')
      return bad(message)
    }
  }
  if(typeof b.username!=='string'||typeof b.password!=='string')return bad('Username and password are required')
  const r=await login(b.username,b.password)
  if(!r)return bad('Invalid username or password',401)
  if(b.role&&r.user.role!==b.role)return bad('Please use the correct portal for this account',403)
  return ok({ok:true,user:r.user},{headers:{'Set-Cookie':cookie(r.token)}})
}}}})
