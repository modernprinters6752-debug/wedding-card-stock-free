import { createFileRoute } from '@tanstack/react-router'
import { bad, currentUser, db, getSetting, MIN_QTY, ok, whatsappLink } from '../../lib/app.server'

export const Route = createFileRoute('/api/orders')({
  server: { handlers: { POST: async ({ request }) => {
    const u = await currentUser(request)
    if (!u || u.role !== 'customer') return bad('Customer access required', 403)
    const b = await request.json() as any
    const items = Array.isArray(b.items) ? b.items : []
    if (!items.length) return bad('Add at least one card')
    for (const i of items) {
      if (!Number.isInteger(Number(i.card_id)) || !Number.isInteger(Number(i.quantity)) || Number(i.quantity) < MIN_QTY) return bad(`Minimum quantity is ${MIN_QTY} PCS per card`)
    }
    const d = db()
    const rs = await d.batch(items.map((i:any) => d.prepare('UPDATE cards SET stock=stock-? WHERE id=? AND active=1 AND stock>=?').bind(Number(i.quantity), Number(i.card_id), Number(i.quantity))))
    if (rs.some(x => Number(x.meta.changes) !== 1)) return bad('One or more cards do not have enough stock', 409)
    try {
      const o = await d.prepare("INSERT INTO orders(customer_id,status) VALUES(?,'placed')").bind(u.id).run()
      const id = Number(o.meta.last_row_id)
      await d.batch(items.map((i:any) => d.prepare('INSERT INTO order_items(order_id,card_id,quantity) VALUES(?,?,?)').bind(id, Number(i.card_id), Number(i.quantity))))
      const lines:string[] = []
      for (const i of items) {
        const c = await d.prepare('SELECT card_no,title FROM cards WHERE id=?').bind(Number(i.card_id)).first<any>()
        lines.push(`${c?.card_no || i.card_id} · ${c?.title || 'Card'} × ${Number(i.quantity)} PCS`)
      }
      const adminWhatsapp = await getSetting('admin_whatsapp_number')
      const message = `🟢 NEW WEDDING CARD ORDER\nOrder #${id}\nCustomer: ${u.name}\nWhatsApp: +${u.username}\n\n${lines.join('\n')}\n\nTotal PCS: ${items.reduce((s:any,i:any) => s + Number(i.quantity), 0)}\nPlease confirm this order.`
      return ok({ ok: true, order_id: id, whatsapp_url: adminWhatsapp ? whatsappLink(adminWhatsapp, message) : '' })
    } catch {
      await d.batch(items.map((i:any) => d.prepare('UPDATE cards SET stock=stock+? WHERE id=?').bind(Number(i.quantity), Number(i.card_id))))
      return bad('Could not save order', 500)
    }
  } } }
})
